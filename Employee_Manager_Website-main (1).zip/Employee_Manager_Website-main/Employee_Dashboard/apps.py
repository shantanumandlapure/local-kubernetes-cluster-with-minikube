from django.apps import AppConfig


class EmployeeDashboardConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Employee_Dashboard'
